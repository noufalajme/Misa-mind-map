// تشغيل القائمة في الهاتف المحمول
const burger = document.querySelector('.burger');
const nav = document.querySelector('.nav-links');

burger.addEventListener('click', () => {
    nav.classList.toggle('nav-active');
    burger.classList.toggle('toggle');
});

// عرض السنوات الدراسية
const studyYears = ["السنة التحضيرية", "السنة الأولى", "السنة الثانية", "السنة الثالثة", "السنة الرابعة"];
const yearsList = document.getElementById('studyYearsList');
const messageDiv = document.getElementById('studentMessage');

// إنشاء قائمة السنوات الدراسية
let yearsHTML = "<h3>المراحل الدراسية:</h3>";
for (let i = 0; i < studyYears.length; i++) {
    yearsHTML += `<div class='year-item'>${studyYears[i]}</div>`;
}
yearsList.innerHTML = yearsHTML;

// سؤال الطالب عن سنته الدراسية
const studentYear = prompt("ما هي سنة دراستك؟ (1-5):", "");
let message = "";

if (studentYear == 1) {
    message = "مرحباً بك في بداية رحلتك الأكاديمية";
} else if (studentYear >= 2 && studentYear <= 4) {
    message = "استمر في التميز والإنجاز";
} else if (studentYear == 5) {
    message = "أنت على وشك التخرج، تهانينا!";
} else {
    message = "الرجاء إدخال سنة دراسية صحيحة";
}

messageDiv.innerHTML = `<div class='student-message'>${message}</div>`;

// Form Validation
document.addEventListener('DOMContentLoaded', function() {
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form fields
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const message = document.getElementById('message').value;
            
            // Simple validation
            if (!name || !email || !message) {
                alert('الرجاء تعبئة جميع الحقول المطلوبة');
                return;
            }
            
            // Email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                alert('الرجاء إدخال بريد إلكتروني صحيح');
                return;
            }
            
            // Show success message
            const successMessage = document.querySelector('.success-message');
            if (successMessage) {
                successMessage.style.display = 'block';
                contactForm.reset();
                
                // Hide success message after 3 seconds
                setTimeout(() => {
                    successMessage.style.display = 'none';
                }, 3000);
            }
        });
    }
});
